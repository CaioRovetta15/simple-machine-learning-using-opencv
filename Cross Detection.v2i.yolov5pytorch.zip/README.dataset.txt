# Cross Detection > 2022-08-30 12:31am
https://universe.roboflow.com/object-detection/cross-detection-aozdj

Provided by Roboflow
License: CC BY 4.0

